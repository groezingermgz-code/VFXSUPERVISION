// Zentrale Versionsangabe für die App
export const APP_VERSION_LABEL = 'Alpha 0.1.4';